# LAST DOT – نقطه آخر

A Persian, mobile-first arcade game and Express server scaffold.

## Requirements
- Node.js 18+
- npm

## Run locally
1. Copy `.env.example` to `.env`.
2. Install dependencies: `npm install`
3. Start: `npm start`
4. Open `http://localhost:3000`

In development mode, the explicit **local development preview** button opens the game. In production, access stays locked until verified Eitaa authentication and official membership checks are implemented.

## Included
- Canvas circular-lane arcade gameplay with touch/click lane switching
- Endless mode and 100 unlockable level slots
- Local high scores, coins, skins, daily missions, settings and stats
- Express server, basic security headers and API rate limiting
- Required-channel landing screen for `@MITHAQDigital` and `@Mehdilands`

## Important Eitaa limitation
This project does **not** claim real Eitaa authentication or real channel membership verification. The `/api/membership/check` endpoint deliberately returns HTTP 503 and `verified: false`. Do not change this to a successful response or bypass it with localStorage.

Before production:
1. Confirm the current official Eitaa Mini App SDK and its exact authentication payload.
2. Implement server-side signature validation exactly as documented by Eitaa.
3. Confirm an official, authorized API method that can check a specific user's membership in both channels.
4. Implement the adapter on the server and test positive, negative, expired, malformed and unavailable responses.
5. Use HTTPS, set a strong `SESSION_SECRET`, configure allowed origins and use a persistent database for accounts/progress.
6. Never commit `.env`, bot tokens, passwords or private keys.

## GitHub / Render
- Commit the project root (including `package.json`, `server/`, `public/`, `.env.example`, `.gitignore`).
- Do not upload `.env`.
- On Render create a Web Service from the repository.
- Build command: `npm install`
- Start command: `npm start`
- Set `NODE_ENV=production`, `SESSION_SECRET`, and `PORT` as supported by the host.
- A free sleeping service may have cold starts; choose an always-on plan for public launch.

## Current status
Playable local prototype + backend scaffold. Not yet production-ready for Eitaa because verified Eitaa identity, official channel membership verification, persistent server-side player data, and full QA on Eitaa Android WebView remain to be completed.
