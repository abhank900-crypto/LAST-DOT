'use strict';
(() => {
  const $=id=>document.getElementById(id);
  const screens=['membership','home','game','result','levels','shop','missions','records','settings'];
  let lastMode='endless',lastLevel=1;
  const skins=[
    {id:'classic',name:'کلاسیک',price:0,color:'#42e8df'},{id:'fire',name:'آتش',price:120,color:'#ff784f'},
    {id:'ice',name:'یخی',price:180,color:'#8bdcff'},{id:'electric',name:'الکتریکی',price:250,color:'#b58cff'},
    {id:'galaxy',name:'کهکشانی',price:350,color:'#e58cff'},{id:'neon',name:'نئون',price:450,color:'#b4ff54'},
    {id:'gold',name:'طلایی',price:600,color:'#ffd36c'}
  ];
  const missions=[
    {id:'score20',title:'امتیازآور',desc:'در مجموع ۲۰ امتیاز کسب کن',target:20,key:'score',reward:35},
    {id:'games5',title:'پرتلاش',desc:'۵ بازی انجام بده',target:5,key:'games',reward:30},
    {id:'dodge30',title:'استاد جاخالی',desc:'از ۳۰ مانع عبور کن',target:30,key:'dodged',reward:50},
    {id:'level1',title:'شروع مسیر',desc:'یک مرحله را تکمیل کن',target:1,key:'level',reward:45}
  ];
  function show(name){
    screens.forEach(s=>$(`${s}-screen`).classList.toggle('hidden',s!==name));
    $('bottom-nav').classList.toggle('hidden',['membership','game','result'].includes(name));
    document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===name));
    if(name==='home')renderHome(); if(name==='shop')renderShop();if(name==='missions')renderMissions();if(name==='records')renderRecords();if(name==='levels')renderLevels();if(name==='settings')renderSettings();
  }
  function renderHome(){const d=Store.get();$('coin-count').textContent=d.coins.toLocaleString('fa-IR');$('home-best').textContent=d.best.toLocaleString('fa-IR');$('home-games').textContent=d.games.toLocaleString('fa-IR');$('home-levels').textContent=d.unlockedLevel.toLocaleString('fa-IR');}
  function renderLevels(){const d=Store.get();$('levels-grid').innerHTML=Array.from({length:100},(_,i)=>`<button class="level-cell" data-level="${i+1}" ${i+1>d.unlockedLevel?'disabled':''}>${(i+1).toLocaleString('fa-IR')}</button>`).join('');$('levels-grid').querySelectorAll('button:not(:disabled)').forEach(b=>b.onclick=()=>start('level',Number(b.dataset.level)));}
  function renderShop(){const d=Store.get();$('coin-count').textContent=d.coins.toLocaleString('fa-IR');$('skins-list').innerHTML=skins.map(s=>{const own=d.ownedSkins.includes(s.id),selected=d.selectedSkin===s.id;return `<div class="skin-card"><div class="skin-left"><i class="skin-dot" style="background:${s.color};color:${s.color}"></i><div><b>${s.name}</b><small>${own?(selected?'انتخاب‌شده':'خریداری‌شده'):`${s.price.toLocaleString('fa-IR')} سکه`}</small></div></div><button data-skin="${s.id}">${selected?'فعال':own?'انتخاب': 'خرید'}</button></div>`}).join('');$('skins-list').querySelectorAll('button').forEach(b=>b.onclick=()=>{const s=skins.find(x=>x.id===b.dataset.skin);if(Store.get().ownedSkins.includes(s.id))Store.selectSkin(s.id);else if(Store.ownSkin(s.id,s.price))Store.selectSkin(s.id);else alert('سکه کافی نداری!');renderShop();});}
  function renderMissions(){const d=Store.get();$('coin-count').textContent=d.coins.toLocaleString('fa-IR');$('missions-list').innerHTML=missions.map(m=>{const p=d.missionProgress[m.key]||0,done=p>=m.target,claimed=d.missionClaimed.includes(m.id);return `<div class="mission-card"><div><b>${m.title}</b><small>${m.desc} · ${Math.min(p,m.target).toLocaleString('fa-IR')}/${m.target.toLocaleString('fa-IR')}</small></div><button data-mission="${m.id}" ${!done||claimed?'disabled':''}>${claimed?'دریافت شد':`دریافت ${m.reward} سکه`}</button></div>`}).join('');$('missions-list').querySelectorAll('button:not(:disabled)').forEach(b=>b.onclick=()=>{const m=missions.find(x=>x.id===b.dataset.mission);Store.claimMission(m.id,m.reward);renderMissions();});}
  function renderRecords(){const d=Store.get();$('records-list').innerHTML=[['بهترین رکورد',d.best],['رکورد بی‌نهایت',d.bestEndless],['رکورد مرحله‌ای',d.bestLevel],['تعداد بازی‌ها',d.games],['مجموع امتیازها',d.totalScore],['موانع پشت‌سرگذاشته‌شده',d.totalDodged],['مراحل تکمیل‌شده',d.completedLevels]].map(([a,b])=>`<div class="record-card"><span>${a}</span><b>${Number(b).toLocaleString('fa-IR')}</b></div>`).join('');}
  function renderSettings(){const s=Store.get().settings;$('sound-setting').checked=s.sound;$('vibration-setting').checked=s.vibration;$('particles-setting').checked=s.particles;}
  function start(mode,level=1){lastMode=mode;lastLevel=level;show('game');$('best-inline').textContent=`رکورد: ${Store.get().best.toLocaleString('fa-IR')}`;Game.start(mode,level);}
  $('start-endless').onclick=()=>start('endless');$('open-levels').onclick=()=>show('levels');
  document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.page)));
  document.querySelectorAll('.back-home').forEach(b=>b.onclick=()=>show('home'));
  $('pause-game').onclick=()=>{if(Game.running){Game.pause();if(confirm('بازی متوقف شد. ادامه می‌دهی؟')){show('game');Game.resume();}else show('home');}};
  $('retry').onclick=()=>start(lastMode,lastLevel);$('go-home').onclick=()=>show('home');
  window.addEventListener('lastdot:end',e=>{const d=e.detail;show('result');$('final-score').textContent=d.score.toLocaleString('fa-IR');$('new-record').classList.toggle('hidden',!d.newRecord);$('result-title').textContent=d.won?'مرحله را بردی!':'بازی تمام شد!';$('result-message').textContent=`${d.reward.toLocaleString('fa-IR')} سکه گرفتی. ${d.won?'مرحله بعدی باز شد!':'برای رکورد بهتر دوباره تلاش کن.'}`;renderHome();});
  window.addEventListener('lastdot:pause',()=>{});
  ['sound','vibration','particles'].forEach(k=>{$(`${k}-setting`).onchange=e=>Store.setting(k,e.target.checked);});
  $('check-membership').onclick=async()=>{const msg=$('membership-message');msg.textContent='در حال درخواست بررسی از سرور…';try{const r=await fetch('/api/membership/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});const data=await r.json();msg.textContent=data.message||'امکان تأیید عضویت وجود ندارد.';}catch{msg.textContent='در حال حاضر امکان بررسی عضویت وجود ندارد. لطفاً دوباره تلاش کنید.';}};
  $('preview-button').onclick=async()=>{try{const r=await fetch('/api/access/status');const d=await r.json();if(d.mode==='development-preview'&&d.canPlay)show('home');else $('membership-message').textContent='پیش‌نمایش فقط در محیط توسعه فعال است.';}catch{$('membership-message').textContent='سرور در دسترس نیست.';}};
  // Production begins on the locked membership screen. Local development can use the explicit preview.
  show('membership');
})();
