'use strict';
(() => {
  const canvas = document.getElementById('game-canvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  const TAU = Math.PI * 2;
  const skins = {
    classic: '#42e8df', fire: '#ff784f', ice: '#8bdcff', electric: '#b58cff',
    galaxy: '#e58cff', neon: '#b4ff54', gold: '#ffd36c'
  };
  let raf=0, running=false, angle=-Math.PI/2, lane=0, score=0, dodged=0, mode='endless', level=1;
  let speed=1.25, obstacles=[], particles=[], last=0, spawn=0, width=0, height=0, dpr=1, switchFlash=0;
  const center=()=>({x:width/2,y:height/2});
  const radii=()=>Math.min(width,height)*.25;
  function resize(){
    const r=canvas.getBoundingClientRect(); dpr=Math.min(window.devicePixelRatio||1,2);
    width=Math.max(1,r.width); height=Math.max(1,r.height);
    canvas.width=Math.round(width*dpr); canvas.height=Math.round(height*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  window.addEventListener('resize',resize);
  function start(nextMode='endless', nextLevel=1){
    cancelAnimationFrame(raf); resize(); running=true; mode=nextMode; level=nextLevel;
    angle=-Math.PI/2; lane=0; score=0; dodged=0; speed=1.2+Math.min(1.4,(level-1)*.025);
    obstacles=[]; particles=[]; last=0; spawn=0; switchFlash=0;
    document.getElementById('score').textContent='۰';
    document.getElementById('mode-label').textContent=mode==='level'?'مرحله‌ای':'بی‌نهایت';
    document.getElementById('level-chip').textContent=mode==='level'?`مرحله ${level}`:'بی‌نهایت';
    raf=requestAnimationFrame(loop);
  }
  function switchLane(){
    if(!running)return;
    lane=1-lane; switchFlash=.18;
    if(Store.get().settings.vibration && navigator.vibrate) navigator.vibrate(10);
    const c=center(), r=radii()*(lane===0?.72:1.28);
    for(let i=0;i<8;i++)particles.push({x:c.x+Math.cos(angle)*r,y:c.y+Math.sin(angle)*r,vx:(Math.random()-.5)*90,vy:(Math.random()-.5)*90,t:.35});
  }
  function spawnObstacle(){
    // Obstacles are placed ahead with a generous angular reaction window.
    const targetLane=Math.random()<.48?0:1;
    const gap=Math.random()*1.2-.6;
    obstacles.push({a:angle+1.55+gap,lane:targetLane,passed:false});
  }
  function draw(){
    ctx.fillStyle='#080d1c';ctx.fillRect(0,0,width,height);
    const c=center(), base=radii();
    const glow=ctx.createRadialGradient(c.x,c.y,2,c.x,c.y,base*1.8);
    glow.addColorStop(0,'#182b4c');glow.addColorStop(1,'#080d1c');ctx.fillStyle=glow;ctx.fillRect(0,0,width,height);
    [base*.72,base*1.28].forEach((r,i)=>{
      ctx.beginPath();ctx.arc(c.x,c.y,r,0,TAU);ctx.strokeStyle=i===lane?'#42e8dfaa':'#60749a55';ctx.lineWidth=i===lane?3:2;ctx.stroke();
    });
    obstacles.forEach(o=>{
      const r=base*(o.lane===0?.72:1.28), x=c.x+Math.cos(o.a)*r,y=c.y+Math.sin(o.a)*r;
      ctx.save();ctx.translate(x,y);ctx.rotate(o.a+Math.PI/2);
      ctx.shadowBlur=13;ctx.shadowColor='#ff6b68';ctx.fillStyle='#ff6b68';ctx.fillRect(-7,-17,14,34);ctx.restore();
    });
    const r=base*(lane===0?.72:1.28), x=c.x+Math.cos(angle)*r,y=c.y+Math.sin(angle)*r;
    const color=skins[Store.get().selectedSkin]||skins.classic;
    ctx.beginPath();ctx.arc(x,y,8,0,TAU);ctx.fillStyle=color;ctx.shadowBlur=24;ctx.shadowColor=color;ctx.fill();ctx.shadowBlur=0;
    ctx.beginPath();ctx.arc(c.x,c.y,3,0,TAU);ctx.fillStyle='#d9e7ff';ctx.fill();
    particles.forEach(p=>{ctx.globalAlpha=Math.max(0,p.t/.35);ctx.fillStyle=color;ctx.fillRect(p.x,p.y,3,3);});ctx.globalAlpha=1;
  }
  function loop(ts){
    if(!running)return;
    const dt=Math.min(.034,(ts-last||16)/1000);last=ts;
    const angular=speed*(1+score*.012);
    angle=(angle+angular*dt)%(TAU);
    spawn+=dt;
    if(spawn>Math.max(.68,1.35-score*.012)){spawn=0;spawnObstacle();}
    for(const o of obstacles){
      o.a-=angular*dt;
      if(!o.passed && o.a<angle-.04){o.passed=true;score++;dodged++;document.getElementById('score').textContent=score.toLocaleString('fa-IR');}
      // Collision check when obstacle reaches player's angular position.
      const delta=Math.atan2(Math.sin(o.a-angle),Math.cos(o.a-angle));
      if(!o.passed && Math.abs(delta)<.075 && o.lane===lane){end();return;}
    }
    obstacles=obstacles.filter(o=>!o.passed && o.a>angle-1.1);
    particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.t-=dt;});particles=particles.filter(p=>p.t>0);
    if(mode==='level' && score>=8+Math.floor((level-1)*1.4)){end(true);return;}
    if(Store.get().settings.particles)draw();else{const old=Store.get().settings.particles;draw();}
    raf=requestAnimationFrame(loop);
  }
  function end(won=false){
    running=false;cancelAnimationFrame(raf);
    const reward=Math.max(1,Math.floor(score/3)+(won?8:0));
    Store.recordRun(score,dodged,mode,level);Store.addCoins(reward);
    const newRecord=score>=Store.get().best;
    window.dispatchEvent(new CustomEvent('lastdot:end',{detail:{score,reward,newRecord,won,mode,level,dodged}}));
  }
  function pause(){if(!running)return;running=false;cancelAnimationFrame(raf);window.dispatchEvent(new Event('lastdot:pause'));}
  function resume(){if(running)return;running=true;last=0;raf=requestAnimationFrame(loop);}
  canvas.addEventListener('pointerdown',e=>{e.preventDefault();switchLane();});
  window.Game={start,pause,resume,get running(){return running;},get score(){return score;}};
})();
