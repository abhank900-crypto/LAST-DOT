'use strict';
(() => {
  const KEY = 'last-dot-save-v1';
  const defaults = {
    best: 0, bestEndless: 0, bestLevel: 0, coins: 0, games: 0, totalScore: 0,
    totalDodged: 0, completedLevels: 0, unlockedLevel: 1,
    ownedSkins: ['classic'], selectedSkin: 'classic',
    settings: { sound: true, vibration: true, particles: true },
    missionDate: new Date().toISOString().slice(0,10),
    missionProgress: { score: 0, games: 0, dodged: 0, level: 0 },
    missionClaimed: []
  };
  function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
      return { ...structuredClone(defaults), ...saved,
        settings: { ...defaults.settings, ...(saved.settings || {}) },
        missionProgress: { ...defaults.missionProgress, ...(saved.missionProgress || {}) } };
    } catch { return structuredClone(defaults); }
  }
  let data = load();
  function save() { localStorage.setItem(KEY, JSON.stringify(data)); }
  function refreshMissions() {
    const today = new Date().toISOString().slice(0,10);
    if (data.missionDate !== today) {
      data.missionDate = today;
      data.missionProgress = { score: 0, games: 0, dodged: 0, level: 0 };
      data.missionClaimed = [];
      save();
    }
  }
  refreshMissions();
  window.Store = {
    get: () => data,
    save,
    addCoins(n) { data.coins = Math.max(0, data.coins + Math.floor(n)); save(); },
    recordRun(score, dodged, mode, level) {
      data.games++; data.totalScore += score; data.totalDodged += dodged;
      data.best = Math.max(data.best, score);
      if (mode === 'endless') data.bestEndless = Math.max(data.bestEndless, score);
      if (mode === 'level') {
        data.bestLevel = Math.max(data.bestLevel, score);
        if (score >= 8 + Math.floor((level-1)*1.4)) {
          data.unlockedLevel = Math.max(data.unlockedLevel, Math.min(100, level+1));
          data.completedLevels = Math.max(data.completedLevels, data.unlockedLevel-1);
          data.missionProgress.level++;
        }
      }
      data.missionProgress.score += score;
      data.missionProgress.games++;
      data.missionProgress.dodged += dodged;
      save();
    },
    claimMission(id, reward) {
      refreshMissions();
      if (data.missionClaimed.includes(id)) return false;
      data.missionClaimed.push(id); data.coins += reward; save(); return true;
    },
    ownSkin(id, price) {
      if (data.ownedSkins.includes(id) || data.coins < price) return false;
      data.coins -= price; data.ownedSkins.push(id); save(); return true;
    },
    selectSkin(id) { if (data.ownedSkins.includes(id)) { data.selectedSkin = id; save(); return true; } return false; },
    setting(key, value) { data.settings[key] = value; save(); }
  };
})();
