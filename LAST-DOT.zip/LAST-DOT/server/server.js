'use strict';
require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));

// This project does not pretend that a browser flag or localStorage proves channel membership.
// Production access remains locked until a verified Eitaa auth + membership adapter is implemented.
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, app: 'LAST DOT', membership: 'not-configured' });
});

app.get('/api/access/status', (_req, res) => {
  if (!isProduction) {
    return res.json({ mode: 'development-preview', canPlay: true, membershipRequired: true });
  }
  return res.status(503).json({
    mode: 'locked',
    canPlay: false,
    membershipRequired: true,
    reason: 'Eitaa identity verification and official channel membership verification are not configured.'
  });
});

app.post('/api/membership/check', (_req, res) => {
  // Fail closed: never accept user-supplied IDs, booleans, or localStorage as proof.
  return res.status(503).json({
    verified: false,
    channels: [
      { username: 'MITHAQDigital', verified: false, status: 'unavailable' },
      { username: 'Mehdilands', verified: false, status: 'unavailable' }
    ],
    message: 'بررسی واقعی عضویت هنوز به API رسمی و مجاز ایتا متصل نشده است.'
  });
});

app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.listen(PORT, () => {
  console.log(`LAST DOT is running on http://localhost:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
